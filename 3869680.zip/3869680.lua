-- 3869680's Lua and Manifest Created by Morrenus
-- Silent Still 2
-- Created: October 02, 2025 at 10:04:23 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3869680) -- Silent Still 2
-- MAIN APP DEPOTS
addappid(3869681, 1, "9ddce3458ea9f0dab580448841013dfb9d668d0424934a492bed2f8abbbafd86") -- Depot 3869681
setManifestid(3869681, "4130377789863100814", 4261318082)