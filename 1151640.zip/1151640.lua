-- 1151640 Manifest and Lua created by Evan
-- Horizon Zero Dawn™ Complete Edition
-- Created: November 24, 2025 at 08:58:44 (UTC)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(1151640) -- Horizon Zero Dawn™ Complete Edition
-- setManifestid(228988,"6645201662696499616")
addappid(1151641,0,"df518a946513a91a56704336384864918ec740df8537ca1812a8f54264355361")
-- setManifestid(1151641,"3712644444013817231")
addappid(1151642,0,"59255c4691e86b0813ddced2314be6ac433c80eacb80b7d716c1cc76ca2032f2")
-- setManifestid(1151642,"6403385661621685335")
addappid(1151644,0,"8a4848c62e8fcd4b79f78195190e4595e6c74b9a81ebe42b60e82bdd9b4b5c17")
-- setManifestid(1151644,"7685822332590815529")