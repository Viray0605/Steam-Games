-- 1458140 Manifest and Lua created by Evan
-- Pacific Drive
-- Created: November 25, 2025 at 07:47:54 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(1458140) -- Pacific Drive
-- setManifestid(228988,"6645201662696499616")
-- setManifestid(228990,"1829726630299308803")
addappid(1458141,0,"006e2d6e9d40e35f8533859d38ce7f71cb41794bcd91cc1c67617d86a13a6395")
-- setManifestid(1458141,"5828865602554873946")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3594760) -- Pacific Drive: Whispers in the Woods
addappid(4097820) -- Pacific Drive: Whispers in the Woods Soundtrack
addappid(3242220) -- Pacific Drive: Frosted Customization Pack
addappid(3073780) -- Pacific Drive: Anomalous Customization Pack
addappid(2935180) -- Pacific Drive: Friendly Dumpster Customization Pack
addappid(2646730) -- Pacific Drive: We Have Liftoff Customization Pack
addappid(2790060) -- Pacific Drive: Official Game Soundtrack
