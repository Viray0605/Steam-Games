-- 1771300 Manifest and Lua created by Evan
-- Kingdom Come: Deliverance II
-- Created: November 10, 2025 at 08:06:43 (UTC)
-- Total Depots: 8
-- Total DLCs: 0

-- MAIN APPLICATION





addappid(1771300) -- Kingdom Come: Deliverance II
-- setManifestid(228989,"3514306556860204959")
addappid(1771302,0,"41bc41c39ce79db318e98b533bab1fe71bfd294c4e8c90f90e4f8efa5fcc2a91")
-- setManifestid(1771302,"3544488985586875723")
addappid(1771303,0,"397ab2e5c59bbb75f716c30dba3374be8af7ff49a2fc45c621e0bc23bafbd5f3")
-- setManifestid(1771303,"7417037405751139280")
addappid(1771305,0,"66d5a42e0171363eac9b79352c78401952d616880979d26967c385d2d7a88368")
-- setManifestid(1771305,"4646920070999016242")
addappid(1771306,0,"120aed0e767afa1ac85539240704d613b82c13473fcd7136d3cea555a784783e")
-- setManifestid(1771306,"725648561472919950")
addappid(1771307,0,"8d47328b0b82d9b9ba25bfb199c69ea2dd005954298bd2aff2b448321569b727")
-- setManifestid(1771307,"1176397216058495539")
addappid(1771308,0,"b457fdf0e78f3465b9ccbfed5f8ecbb85f22428ba321534ee0df4a0d08754d02")
-- setManifestid(1771308,"8664781500674004426")
addappid(1771309,0,"1f8b55f9f4ac27eac8ffa310ca46163ee5aaad0937438035274a30b78de4e81a")
-- setManifestid(1771309,"7822220232979156168")
addappid(3118101,0,"69d3aecd16754fea50cf46182e56be5d29647e571e45c1dd1ef3294b966d0ee4")
-- setManifestid(3118101,"284584102760554243")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3368620) -- Kingdom Come: Deliverance II Mysteria Ecclesiae
addappid(3368610) -- Kingdom Come: Deliverance II Legacy of the Forge
addappid(3119920) -- Kingdom Come: Deliverance II Expansion Pass
addappid(3368600) -- Kingdom Come: Deliverance II Brushes with Death
addappid(3468550) -- Kingdom Come: Deliverance II Soundtrack
addappid(3118100) -- Kingdom Come: Deliverance II The Lion’s Crest
addappid(3118110) -- Kingdom Come: Deliverance II Gallant Huntsman’s Kit
addappid(3118120) -- Kingdom Come: Deliverance II Shields of Seasons Passing
