-- 2233120 Manifest and Lua created by Evan
-- A Quiet Place: The Road Ahead
-- Created: December 27, 2025 at 12:12:43 (UTC)
-- Total Depots: 1
-- Total DLCs: 0


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION

addappid(2233120) -- A Quiet Place: The Road Ahead
addappid(2233121,0,"908cc3ca235e2d744c3f800596e90f596fe3b9acd68a130ec56985fbdf262212")
-- setManifestid(2233121,"9154476076427286724")