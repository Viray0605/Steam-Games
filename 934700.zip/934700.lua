-- 934700 Manifest and Lua created by Evan
-- Dead Island 2
-- Created: October 30, 2025 at 02:50:14 
-- Total Depots: 3
-- Total DLCs: 0
-- MAIN APPLICATION


-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(934700) -- Dead Island 2
addappid(934701,0,"9f01bb4de4308fcda3524d8e086fb30c2cee5a647bc41b8ca77afad561bde375")
-- setManifestid(934701, "4520157714470513458")
addappid(934702,0,"74f4653f5c8cd21938bd4a269765ee3310d860bbf57e7fcc44dd02751f277a49")
-- setManifestid(934702, "2858245023909888152")
addappid(934703,0,"58de2f171f82b74cb47ade0cbc87eb4a5046814bdf0bf1b6d359625a63543852")
-- setManifestid(934703, "1968873050790886925")
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2667910) -- Dead Island 2 - Kingdom Come: Deliverance II Weapons Pack
addappid(2813110) -- Dead Island 2 - Expansion Pass
addappid(2813310) -- Dead Island 2 - SoLA
addappid(2813100) -- Dead Island 2 - Haus
addappid(2813030) -- Dead Island 2 - Red’s Demise Katana
addappid(2813010) -- Dead Island 2 - Golden Weapons Pack
addappid(2813020) -- Dead Island 2 - Pulp Weapons Pack
addappid(2813000) -- Dead Island 2 - Memories of Banoi Pack
addappid(2813040) -- Dead Island 2 - Character Pack: Silver Star Jacob
addappid(2813050) -- Dead Island 2 - Character Pack: Cyber Slayer Amy
addappid(2813060) -- Dead Island 2 - Character Pack: Gaelic Queen Dani
addappid(2813070) -- Dead Island 2 - Character Pack: Jungle Fantasy Ryan
addappid(2813080) -- Dead Island 2 - Character Pack: Steel Horse Carla
addappid(2813090) -- Dead Island 2 - Character Pack: Venice Vogue Bruno