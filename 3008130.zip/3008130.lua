-- 3008130 Manifest and Lua created by Evan
-- Dying Light: The Beast
-- Created: November 16, 2025 at 02:22:24 (UTC)
-- Total Depots: 25
-- Total DLCs: 3


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION 




addappid(3008130) -- Dying Light: The Beast

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3592040) -- Dying Light: The Beast - Hero Of Harran Bundle
addappid(3707650) -- Dying Light: The Beast - Castor Woods Prepper Bundle
addappid(3707710) -- Dying Light: The Beast Standard to Deluxe Upgrade
addappid(3008131,0,"3c9721275b2d1577cdbc46948aaef80104cd4f45a9bc32c20e03345c54652587")
-- setManifestid(3008131,"7509236200935396898")
addappid(3707621,0,"04cd9ab87835457d4a64c2e33c8bfb34ec9873a58306082dd1554fa31e61b08c")
-- setManifestid(3707621,"6257965437662766979")
addappid(3707622,0,"dbba296c59b4dd12cfbf3e831d228341905cbfe72a6f39b9ab9ab535e2aa2390")
-- setManifestid(3707622,"5184198940762274725")
addappid(3707623,0,"e7a49cf3e8049304b31ac9af2380050346b19274b6429680fa656ca2ef8132ff")
-- setManifestid(3707623,"8410235877528022390")
addappid(3008132,0,"6028aa5b91f9bf95194ec527c2ebdccd62e9a5df423e65ce32a73145aaa6c6b3")
-- setManifestid(3008132,"6129248470601310306")
addappid(3008133,0,"434623d389db7ee032958e856f56adcc7da748791f86963e54523321e2e57ee9")
-- setManifestid(3008133,"7162549516586910100")
addappid(3008134,0,"9c4e2acba05efb8e83b8b84191c8ea0454009ee00e7fc407eb32ad2c16cd5d9e")
-- setManifestid(3008134,"9179387896156765641")
addappid(3008135,0,"d47e689c1f7c949b76c2d74d998ef7cf4db0ebb66ef327e68a4e7e1b4bc931dd")
-- setManifestid(3008135,"3302140328572812531")
addappid(3592041,0,"32f10ad2de76688dc0970aebede422b2921593489edc03e6e1e90d447aeb3890")
-- setManifestid(3592041,"8158869557748837661")
addappid(3008136,0,"4246c4c3f664e9ac92b6f9bdabea8f9d178d64e7b7f78ce2e47d3261e429d21f")
-- setManifestid(3008136,"5118554309972544426")
addappid(3008137,0,"91d23606572ed7cd2a17f0a53854b43ab17be7f90b9121c2e133df6bf9628b15")
-- setManifestid(3008137,"7777071899792642998")
addappid(3008138,0,"b087b304a3080e8bb9b868f067c8b57d6eac1c0018d81a8d563cc7dcaf6ca050")
-- setManifestid(3008138,"5274031753658698737")
addappid(3008139,0,"9ca49a179625bb0a94c6cef85afa175dbf6f70f640eea01565cf29ee9b89b1a4")
-- setManifestid(3008139,"7816104546630776041")
addappid(3061861,0,"2f7e9b1d05e7bc30e55829af984f423c7891ecb354db0e336f3cc8f8115aa9a8")
-- setManifestid(3061861,"2335666416850868800")
addappid(3061862,0,"58441f3a3fc23c78ee6ae062b402e98c3881f13b870b2945df538700a9ee98ee")
-- setManifestid(3061862,"7122497716371188225")
addappid(3061863,0,"5046b1035705c5b2cb125dcffa5f4e5e2fc859a4be1568f05cb1690cd5d8a2ed")
-- setManifestid(3061863,"3745747438983156086")
addappid(3061864,0,"38076b913ef2e4d848b83c972e455b0ed335321b7b3275f956819d56618137cc")
-- setManifestid(3061864,"2445665158966068362")
addappid(3061865,0,"062b2caf7c45bb6c993a1ccc89d4241601e83976f43b4d7a4ec73b6e87a23baf")
-- setManifestid(3061865,"421275576384794492")
addappid(3061866,0,"da6a491e78d34f913d3a35f81992ad8b9554a45ad3405eb90104535c2a190a1c")
-- setManifestid(3061866,"4493211221650038217")
addappid(3061867,0,"72b42328ca9c827d6c99a336214d08101a2d1ea131aa4c646a506d94d5c25594")
-- setManifestid(3061867,"5688308701501720197")
addappid(3061868,0,"4a4e46600e98b44593fe9d6c5f32ffaee4984a804a65841da31aa5f3d562e9c5")
-- setManifestid(3061868,"2535062348320643356")
addappid(3061869,0,"a3cc7e3956b21127479c97bde2183a0350a0e00b1866e328210cfd18f9449d2a")
-- setManifestid(3061869,"4737371169622468217")
addappid(3592042,0,"55b8d3f1f8f7b6a5285b4c11635a22a47948493c275ac657e6a3e7ec22a0912b")
-- setManifestid(3592042,"1143550279580487275")
addappid(3592043,0,"d6564bfa4427ac630cf6a83e8a8dd0da310c59f95cb79634b17a8ce1822922ae")
-- setManifestid(3592043,"7662049322956876217")
addappid(3592044,0,"d36aeb87d7dc3805c50fbbbbd0a592b0e112ba31cca48aaba4a4b12169ab4a06")
-- setManifestid(3592044,"2072233668492351665")
addappid(3707620) -- Dying Light: The Beast - Official Soundtrack
addappid(3707630) -- Dying Light: The Beast - Castor Woods Tourist Map
addappid(3707640) -- Dying Light: The Beast - Wallpaper Pack
