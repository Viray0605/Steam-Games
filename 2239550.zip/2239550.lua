-- 2239550 Manifest and Lua created by Evan
-- Watch Dogs®: Legion
-- Created: October 25, 2025 at 01:16:08 
-- Total Depots: 12
-- Total DLCs: 0
-- MAIN APPLICATION


-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2239550) -- Watch Dogs®: Legion
-- MAIN APP DEPOTS
addappid(2239551,0,"62572c9c866092b5d5c24f9d76b0d30e122ec188a384cf332863c2354a16e499") -- Depot 2239551
-- setManifestid(2239551, "5409223134227379956")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Depot 1716751
-- setManifestid(1716751, "818295193716041715")
addappid(2239553,0,"aedafe5b1f90390eead5c8b1284c9135978cb376a92d63f3cc50f72cfc25c1b9") -- Depot 2239553
-- setManifestid(2239553, "861626495949591325")
addappid(2239554,0,"7c56b1185c417eb03429ae8d45ac5f601ad32ea1b165aeb4e865d8be81b38057") -- Depot 2239554
-- setManifestid(2239554, "150776765054703772")
addappid(2239555,0,"5264cd8b1760303e1252fddcd7c22b8737ee4072a06c949c17a70567c46f91d0") -- Depot 2239555
-- setManifestid(2239555, "1126084741540836795")
addappid(2239556,0,"cf5f6a46e9a1570e6233eb2635494823fbb6500438ff91f9d9bf5e15dd7f1015") -- Depot 2239556
-- setManifestid(2239556, "1246586549978281605")
addappid(2239557,0,"7ef880457a787df11e53915796a5683e5b4cecbdf13e652cf6b241258670fc46") -- Depot 2239557
-- setManifestid(2239557, "1708196626566240967")
addappid(2239558,0,"96a2343878739aa83ae1594e8308477aae7103b27c47275413b29faf2467962e") -- Depot 2239558
-- setManifestid(2239558, "5263627914238077400")
addappid(2239559,0,"6e573031c1f7df976ba2afd51dc5d9ad29867474e9c89336c319a28746479ba6") -- Depot 2239559
-- setManifestid(2239559, "1849129399140238585")
addappid(2239578,0,"ab14e233729a7f7aa201e66ca2561e17606d2b5ef892d3c3d5576393ad51a296") -- Depot 2239578
-- setManifestid(2239578, "1722712900383029919")
addappid(2239579,0,"c9a01759f720b3981960152bf9935ad070d46a90896d63866b2f5628c2cfda75") -- Depot 2239579
-- setManifestid(2239579, "4016126354565287573")
addappid(2239581,0,"8780ca840c8994c0aea640128c1627f27ed861e147aebcbe0b965a1645a1eb4e") -- Depot 2239581
-- setManifestid(2239581, "2185846408303563524")
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2239575) -- Watch Dogs®: Legion Watch Dogs : Legion - Season Pass
addappid(2239577) -- Watch Dogs®: Legion Watch Dogs Legion : Bloodline