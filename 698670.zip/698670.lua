-- 698670 Manifest and Lua created by Evan
-- Scorn
-- Created: January 30, 2026 at 11:25:56 (UTC)
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION


addappid(698670) -- Scorn
addappid(698671,0,"4e1f1b866d2734e7bebea00a9226a1d1406620391d593824cde754a461253b17")
-- setManifestid(698671,"3802045124937220712")
addappid(2023230,0,"fa6115ec633bab9fcbd3d36a02f38cae3dc7d062710fa19626553964243f9bd9") -- Scorn: Digital Artbook
-- setManifestid(2023230,"5498395678317195685")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2023240) -- Scorn: Original Soundtrack
