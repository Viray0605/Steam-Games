-- 1086940 Manifest and Lua created by Evan
-- Baldur's Gate 3
-- Created: November 20, 2025 at 06:32:33 (UTC)
-- Total Depots: 5
-- Total DLCs: 1


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link : https://guns.lol/f1uxin


-- MAIN APPLICATION 



addappid(1086940) -- Baldur's Gate 3
addappid(2378500,0,"77dfde8ac009c5a510843210ffa1343976be2cc3a303122c9c635fcba725d9cb") -- Baldur's Gate 3 - Digital Deluxe Edition DLC
-- setManifestid(2378500,"6453229909780803137")
addappid(1419653,0,"dc9bee49d256e78104b71d0bf90e9818631b069dce3b576a86fa6345d3b94896")
-- setManifestid(1419653,"4685288946475785993")
addappid(1419652,0,"43c13e12030aed1fdb00bd1c630bd68f0d22cb23289c879b00d7904aa05fcc89")
-- setManifestid(1419652,"779008707202616773")
addappid(1086942,0,"5313c9d372b30e73c15606d9792e5f23314c21559d35f54eb7b5e8369e28b036")
-- setManifestid(1086942,"17875152607970122")
addappid(1086941,0,"4876e089a6bb7a4d8da586306d4040c7d4bd5fb7c05da6c5441a760aa0b2bef6")
-- setManifestid(1086941,"4958838920686552427")
addappid(2378510) --Collector's Edition DLC

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2956320) -- Baldur's Gate 3 Toolkit Data
