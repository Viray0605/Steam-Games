-- 1182900 Manifest and Lua created by Evan
-- A Plague Tale: Requiem
-- Created: November 25, 2025 at 11:49:31 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(1182900) -- A Plague Tale: Requiem
-- setManifestid(228988,"6645201662696499616")
addappid(1182901,0,"89056a553dcf6ee12c8c1a92b728c89e8457fb95ec117f931d7115aa918cbd18")
-- setManifestid(1182901,"3367036266289852265")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1906530) -- A Plague Tale: Requiem - Protector Pack DLC
