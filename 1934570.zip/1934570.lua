-- 1934570 Manifest and Lua created by Evan
-- AppID 1934570
-- Created: November 21, 2025 at 12:07:44 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(1934570) -- AppID 1934570
addtoken(1934570,"4713076652622357934")
-- setManifestid(228989,"3514306556860204959")
-- setManifestid(228990,"1829726630299308803")
addappid(1934571,0,"8339de2d0121af2b4b3a7ec0b461091ae5a3dcfb4f531c1d45aa3640a8715d17")
-- setManifestid(1934571,"6794263031258525399")