-- 1030840 Manifest and Lua created by Evan
-- Mafia: Definitive Edition
-- Created: November 01, 2025 at 07:17:22 (UTC)
-- Total Depots: 3
-- Total DLCs: 0
-- MAIN APPLICATION



-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link : https://guns.lol/f1uxin

addappid(1030840) -- Mafia: Definitive Edition
addappid(1030841,0,"d6e79f53321a7947e8963e27e1baefb862ce738eb51a2fa8eeaa90c476917f64")
-- setManifestid(1030841,"2886022585972111903")
addappid(1316300,0,"724c017202bf35f19f8cdbbec2e6a859a2d88b805b1abe089d4d8a329b318471")
-- setManifestid(1316300,"1697495207204236421")
addappid(1523211,0,"6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
-- setManifestid(1523211,"5488617169383930545")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1421480) -- Mafia: Definitive Edition Soundtrack
