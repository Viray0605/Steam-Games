-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 881020.lua
addappid(881020)
addappid(881021,0,"87a89e2a3e05613b1fa823d2a8d3796cb8e38972563f929ba9bee212ece2a40f")
setManifestid(881021,"96435969733811286")