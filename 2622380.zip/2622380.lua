-- 2622380 Manifest and Lua created by Evan
 -- ELDEN RING NIGHTREIGN
 -- Created: October 25, 2025 at 10:58:57 
 -- Total Depots: 7
 -- Total DLCs: 0
-- MAIN APPLICATION




-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2622380) -- ELDEN RING NIGHTREIGN
-- MAIN APP DEPOTS
addappid(3319490) -- Depot 3319490

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3515610) -- ELDEN RING NIGHTREIGN The Forsaken Hollows
addappid(3637850) -- Depot 3637850
addappid(3515600,0,"698188f58b73df7953b831a1e83a2b75cce4a3ec24d6c8ea3e3869bed96219dd") -- Depot 3515600
-- setManifestid(3515600, "6784183289585886224")
addappid(2622381,0,"c3e9ccfedcda0cd10e53938e15261130b2e166007d2ca8f13aa5a05f06bd2630") -- Depot 2622381
-- setManifestid(2622381, "5280028059154723272")
addappid(2622383,0,"c6e496ba5ae5c8bfa358f3a7d923ec39964fa0a41c4fa77006249fe34e677af2") -- Depot 2622383
-- setManifestid(2622383, "6833690993715375259")
addappid(2622384,0,"029f67382779483e0b34bc2f1a1fae303e7f83a4efead9ed076448f386afd28f") -- Depot 2622384
-- setManifestid(2622384, "6882391047912019949")