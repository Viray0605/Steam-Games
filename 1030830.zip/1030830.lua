-- 1030830 Manifest and Lua created by Evan
-- Mafia II: Definitive Edition
-- Created: November 02, 2025 at 08:18:05 (UTC)
-- Total Depots: 2
-- Total DLCs: 0
-- MAIN APPLICATION




addappid(1030830) -- Mafia II: Definitive Edition
addappid(1030831,0,"32530b6455aff62129bdca96b7eade4476d7d5aa76a6233563dca1ccad754475")
-- setManifestid(1030831,"7075325167535131973")
addappid(1523211,0,"6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
-- setManifestid(1523211,"5488617169383930545")