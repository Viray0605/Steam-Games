-- 1295510 Manifest and Lua created by Evan
-- DRAGON QUEST® XI S: Echoes of an Elusive Age™ - Definitive Edition
-- Created: December 29, 2025 at 01:38:55 (UTC)
-- Total Depots: 1
-- Total DLCs: 0


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION

addappid(1295510) -- DRAGON QUEST® XI S: Echoes of an Elusive Age™ - Definitive Edition
addappid(1295513,0,"940f6f87ded1c6f17229cc6e898c946f8ae111e0f74214543e0d73384711c0f2")
-- setManifestid(1295513,"8306833616847715577")