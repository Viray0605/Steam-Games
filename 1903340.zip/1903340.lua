-- 1903340 Manifest and Lua created by Evan
-- Clair Obscur: Expedition 33
-- Created: November 06, 2025 at 08:49:49 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION





-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1903340) -- Clair Obscur: Expedition 33
addappid(1903341,0,"8593f9c4cd595f833d5344e55cd6c6fdb73d9a4fa05dab033ba71622265e8c82")
-- setManifestid(1903341,"1338324010941565591")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3228520) -- Clair Obscur: Expedition 33 – Deluxe Edition Upgrade
addappid(3405480) -- Clair Obscur: Expedition 33 – Original Soundtrack
addappid(3873750) -- Clair Obscur: Expedition 33 – Nos Vies En Lumière (Bonus Edition)
