-- 239140 Manifest and Lua created by Evan
-- Dying Light
-- Created: November 17, 2025 at 09:01:10 (UTC)
-- Total Depots: 47
-- Total DLCs: 7


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION 


addappid(239140) -- Dying Light
addappid(239153,0,"c6fcdb2d6512b606f1a71ccfd84da3129320ac8e12dbda5697dc44ecf11fad86")
-- setManifestid(239153,"597328146082718135")
addappid(239142,0,"dd4be4c23d15015c47203ba5e576b7d94b1b6bab2d285a6f1d9907d91dc3afcb")
-- setManifestid(239142,"4909222964749487550")
addappid(239141,0,"d43f22eb50617425e906b808de0508b5668219ed5de743ffb6a96d387ab9a5e4")
-- setManifestid(239141,"3836450774946933672")
addappid(239154,0,"bfd86bba87fa2e2fbc783dae0c2d82ea12dcf704223b5e8792b7f024b8e04783")
-- setManifestid(239154,"8548560754683817585")
addappid(239144,0,"9a7e5678376e0b1680258b1ceb7cc050988ed630e40401332dbb4a2c4c9b6873")
-- setManifestid(239144,"248248057168427557")
addappid(239145,0,"9a406d0152999e5ac765192887fe0e4ddcc7b0cb978a5016096d35b14b7942e5")
-- setManifestid(239145,"6378759707341816275")
addappid(302100,0,"f93071cd8a04fff9d35ac709416db9f5f8ed7cbd2000837e66f1224a24eab514")
-- setManifestid(302100,"2873729749703031144")
addappid(239143,0,"784fc854e9b1df1eb26155a776d4898a0a35798e9378bcef02d4dbaf50c42ad8")
-- setManifestid(239143,"3583087257902319723")
addappid(239146,0,"5dc64f1c81d707eea75c7414b4db341e32e7ec5c51831561475fc1e35085c94c")
-- setManifestid(239146,"6977596446358742346")
addappid(239147,0,"3d07ffce6f87a58f62c4c998419b67751cee4fc6cda63134cfafc11eceba6b06")
-- setManifestid(239147,"6818540791695431332")
addappid(239148,0,"0f888096b96297181839f55ec15549e3a5f45e4d3a95e007faed839ab73c472d")
-- setManifestid(239148,"426440171849558497")
addappid(335818,0,"31412e3233e1f94b35343da3ed6df1b3a0fe4856364a0f1f4f718d77b1ce88f8")
-- setManifestid(335818,"4217550357101797215")
addappid(239149,0,"51ba3027452ff645ac04ebea157e620d5a7dc9e69a2615b489a5bfd0dcc1e397")
-- setManifestid(239149,"6910977096862001324")
addappid(239150,0,"a4beca8cbfb6a2e1724935cc8fc91407fda50404785b56f30c5ee9a8f828af20")
-- setManifestid(239150,"6133466168714389736")
addappid(239152,0,"548581b46d068549522f09d9c16f3db62d67377d2461bd239ef4a9f8046e065f")
-- setManifestid(239152,"1116346532221734710")
addappid(239151,0,"472a27da2bafc64d66eacc81028e86787ec574ef87557c9bfc1c85e007f80e35")
-- setManifestid(239151,"6426363688419295291")
addappid(239155,0,"38994ccf16578dd6ecee834c698d9467a4006f2baa52bb4508fda5ba67a1be37")
-- setManifestid(239155,"4136505972728284312")
addappid(239157,0,"2dccf962440b0f9b10bef2dc7c1be9dffbf18628bc7199b2a70c35dbab091c0e")
-- setManifestid(239157,"8150565159504746641")
addappid(239158,0,"ac378571b7679bcdc1d121520eef910fb1594321a3da1c0cb42ddb8861169969")
-- setManifestid(239158,"5758326851910201053")
addappid(239156,0,"7d47deed0dcf10255f1d78245984940a4db077fa63dcfe90d1a43acd73bacfac")
-- setManifestid(239156,"5550976966324161531")
addappid(239159,0,"ca6a14b1a73be972a17a4a74da8c282fa11e21f481faeaac17583b35b3de9d9d")
-- setManifestid(239159,"2822939376127183892")
addappid(325726,0,"df587ce217685b930ca1231ead3c361809aec59d70e1551a9d1bc2e453f775d2")
-- setManifestid(325726,"2852561654468516267")
addappid(325727,0,"8cec0f5de662b30815d9e1fc0b2ed0ddd98c777c17d34c191e5b70e252f85a30")
-- setManifestid(325727,"693555123660047091")
addappid(325728,0,"8cf07633fe357e1530b178be6adc6815c68171db7c52e3724684286ef8224b7e")
-- setManifestid(325728,"1059079872503087232")
addappid(325729,0,"71b442c82934c4edb53e5239ac4be12cc2e3fa08f9cbad06100c422dbd8529ee")
-- setManifestid(325729,"3544563061799568236")
addappid(325723,0,"ea4b42ffe42766d79d3ba8af8fcc61b28901bfab8ebb4ad8ea2920753f4ec442") -- Dying Light - The Bozak Horde
-- setManifestid(325723,"1465870578748186747")
addappid(302105,0,"d586eda8faec228ed8216b9f8915785830722cc601d0886fed441b58628fbb86")
-- setManifestid(302105,"8756888897604089134")
addappid(302106,0,"ea32e751c5c9265cae9993356eda21134e864331942d960e677fdf088cfe4481")
-- setManifestid(302106,"2799419641144961499")
addappid(325724,0,"59d801db2b871628da195dca8a59d4c582c6b204a3892e1570cfa38d7e971090") -- Dying Light: The Following
-- setManifestid(325724,"6059226024133849133")
addappid(412921,0,"c1b9d960bc29fb856a820b810396cf7b063e628fdd430fc2f4f5cb29ad1e24e2")
-- setManifestid(412921,"6232144231768424251")
addappid(335813,0,"5c6ec7e26c577c7f4652707d01411361fc5ef05d1db91d85a25e85fd451d90c5")
-- setManifestid(335813,"4259674798618992744")
addappid(412922,0,"550a7a9c831851105926c9a9fbbb20b5ced04aef4e629087164f19ed865e0085")
-- setManifestid(412922,"8531938917465548160")
addappid(302108,0,"8b500ae36679ec190ce7d9ef7fc0ef40702d28d8ce3147147e999c0cfb0a9cb4")
-- setManifestid(302108,"1850989583263552877")
addappid(302109,0,"c3c2748345f430bfc4864f0fa5e64405f9d6b75a923f2fa49fffca25e093db9b")
-- setManifestid(302109,"79403517218616909")
addappid(335817,0,"005d3890c451828fa134a96a0f5ecfa1493ae139db801af14e46d8926d4d8394")
-- setManifestid(335817,"8479010149025826092")
addappid(412920,0,"49a79ba116a43c0faf88157d3782fa05e87c243b4fa282925833765b40ff40a3")
-- setManifestid(412920,"6822587561065356023")
addappid(412923,0,"38e033dcfd431c291ef7f268b419378ceb258d6293fe5da0964e288ec478c094")
-- setManifestid(412923,"2553264840411748304")
addappid(415370,0,"5b742b871e541b3f673ab3bb9a045d38ddc6611199ad5fb1ee9b4c1511191954")
-- setManifestid(415370,"6599111478640264774")
addappid(302104,0,"e20d95329cf0de87109a1ba47f90db1d5d7354f0d1865320020692338667217a")
-- setManifestid(302104,"4768350597960864245")
addappid(325718,0,"a82801b34ca486a45f4186589d34d58143fe2c80fa9381b12a4bc94e5208321c")
-- setManifestid(325718,"6227690053458630607")
addappid(335811,0,"a2bf0d355bf9857928aaa28c99346f578bb5eadcbb712bdc057d04132572b39f")
-- setManifestid(335811,"5732437539108548227")
addappid(335812,0,"af2ed455ce47b41581e161a7726a34fd1de02f6c267a2924b0d87185746a49e7")
-- setManifestid(335812,"8637297590899825419")
addappid(335814,0,"cc74f4dcd4043130d5cb2b80a32ff930c066f4b0762c584e91bb326a08fab33a")
-- setManifestid(335814,"2325262553779690967")
addappid(335815,0,"9190b1cf9453881520747438121484af7007f4bd6ef9ac11fa49b69f8793d89d")
-- setManifestid(335815,"5506650191026384069")
addappid(325719,0,"f259e29c755201c3110814d2abeab64effa4e52fddf38fcd8df8097aa94c124a")
-- setManifestid(325719,"4176669826358938393")
addappid(335816,0,"0127239b7ec09183956a0819dedd109189ebdc1a4fe3da57dba1870660486a9a")
-- setManifestid(335816,"2654921391239390103")
addappid(798540,0,"f2d0fbc465f9f5de6aa4123106369dccde6e646f37497de93c9bd1ace5a8f1fb") -- Dying Light Original Soundtrack
-- setManifestid(798540,"122531785649024013")
addappid(798541,0,"7bc6d5d780053a9fcbbdeefee19589f1f25d0f605257fe728ccad3fdac856b98") -- Dying Light 3D Printer Models
-- setManifestid(798541,"3431955321588676176")
addappid(798542,0,"1e00c500f2e145f7f8a0a8aa8c45ccc4611dfd78861964393520fd17ef6e7b01") -- Dying Light Collector’s Artbook
-- setManifestid(798542,"8544396478454181413")
addappid(798543,0,"8bde9e319ea58e4958ac96151ab460a48039a292e0a10a52f919a64197c17f97") -- Dying Light Wallpaper Pack
-- setManifestid(798543,"4065307748050454193")
addappid(1034630,0,"e44584224e62e8fb38c5cce8c820311b3417d72e509f5148a8344c0bb8123ad6") -- Dying Light Book
-- setManifestid(1034630,"3262027323823027455")
addappid(335819,0,"40a26d78e3a4bf01c8fab0eb0d87f084049fde55819456e234b90f2d2d9d661b")
-- setManifestid(335819,"5180383747109106484")
addappid(347091,0,"59ef657142ff4d99f9d19904a59b20df2dd95f45aa64000ea026d46692841439")
-- setManifestid(347091,"7581610855260160694")
addappid(347092,0,"bac768ef68e46f172518b62eef2a2ae670199054c7c0e8eec3114b5981a586b8")
-- setManifestid(347092,"8675352565533308493")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3454290) -- Dying Light - 10th Anniversary Bundle
addappid(1300710) -- Dying Light - Hellraid
addappid(748340) -- Dying Light - White Death Bundle
addappid(748341) -- Dying Light - Vintage Gunslinger Bundle
addappid(335810) -- Dying Light: Season Pass
addappid(302101) -- Dying Light - Cuisine & Cargo
addappid(435111) -- Dying Light - Crash Test Skin Bundle
addappid(347090) -- Dying Light - Ultimate Survivor Bundle
addappid(436080) -- Dying Light - Harran Ranger Bundle
addappid(436081) -- Dying Light - Gun Psycho Bundle
addappid(436082) -- Dying Light - Volatile Hunter Bundle
addappid(1112521) -- Dying Light - Godfather Bundle
addappid(1241570) -- Dying Light - 5th Anniversary Bundle
addappid(1272090) -- Dying Light - Unturned Weapon Pack
addappid(1354960) -- Dying Light - Volkan Combat Armor Bundle
addappid(1184350) -- Dying Light - Shu Warrior Bundle
addappid(1174580) -- Dying Light - Harran Inmate Bundle
addappid(1184351) -- Dying Light - Chivalry Weapon Pack
addappid(1454750) -- Dying Light – L4D2 Bill and Gnome Chompski Pack
addappid(1468290) -- Dying Light - Classified Operation Bundle
addappid(1498210) -- Dying Light - Viking: Raiders of Harran Bundle
addappid(1524890) -- Dying Light - Ox Warrior Bundle
addappid(1543420) -- Dying Light - Harran Tactical Unit Bundle
addappid(1599030) -- Dying Light - Rust Weapon Pack
addappid(1647900) -- Dying Light - Savvy Gamer Bundle
addappid(1697640) -- Dying Light
addappid(1702060) -- Dying Light - Astronaut Bundle
addappid(1762700) -- Dying Light - Van Crane Bundle
addappid(1822810) -- Dying Light - Snow Ops Bundle
addappid(1935540) -- Dying Light - Dieselpunk Bundle
addappid(2971370) -- Dying Light - Standard To Enhanced Upgrade
addappid(2971380) -- Dying Light - Standard To Definitive Upgrade
