-- 2631250 Manifest and Lua created by Evan
-- Slitterhead
-- Created: December 29, 2025 at 01:38:18 (UTC)
-- Total Depots: 4
-- Total DLCs: 0


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION

addappid(2631250) -- Slitterhead
addappid(2631251, 1, "35b65353c889458eccf51a3307b040e48e83aff12bddd5bfeb96a787392be005") -- Depot 2631251
-- setManifestid(2631251, "150359154658006113", 27842485425)
addappid(2631252, 1, "bb6e2fdcea1188e89b4fbbc62a18fad23a4580ab83074a3bee8bb5fee9c8eadf") -- Depot 2631252
-- setManifestid(2631252, "431009321496640377", 27842493369)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3172360) -- Slitterhead Digital Soundtrack & Artbook
