-- 1687950 Manifest and Lua created by Evan
-- Persona 5 Royal
-- Created: November 15, 2025 at 06:57:52 (UTC)
-- Total Depots: 10
-- Total DLCs: 0

-- MAIN APPLICATION





-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1687950) -- Persona 5 Royal
addappid(1687951,0,"63d197a9660d17f1f93004f842b51a99590dcb140cfa4b33b67f04b66e3ef2dc")
-- setManifestid(1687951,"179949564195054526")
addappid(1687952,0,"786ef5979ef545b2322dcda59e5f0ccaaadd321a9f6ac7522b6a55198edff0b6")
-- setManifestid(1687952,"3167861682612256520")
addappid(1687953,0,"0d1a567ea2ea013eb35cae7c62deac6973987d8f0cf5585326fc9f0cec3f0868")
-- setManifestid(1687953,"676724932591096292")
addappid(1687954,0,"26d7d88b05209c16a6ca45297dcaaa774b2185b6a74970bac121c1f5cb37b1d9")
-- setManifestid(1687954,"4383202142358403441")
addappid(1687955,0,"987640b74d60f9c60cbf8d2899469cd1d552f00df1da5a3aba3dfa44ea6f375a")
-- setManifestid(1687955,"1440355225172460061")
addappid(1687956,0,"c7b8a0e3c11d039f34b797ce0ce792926c0cb6e70c5cdac969785c85d7d29133")
-- setManifestid(1687956,"7521686342464165318")
addappid(1687957,0,"cd181cf543f85bc275f52e8836e5090293530f895c6109be61bbf8735fd1fa60")
-- setManifestid(1687957,"748315061441883037")
addappid(1687958,0,"bcd88777efb6608bbd36b99c813acfda482f0a0ae1ebbef6844e9f9bb46c5872")
-- setManifestid(1687958,"4651383591850403589")
addappid(1687959,0,"4ed788043739d211ea18eaf3837f9739527b60da089c778b896d9baa05a16415")
-- setManifestid(1687959,"223453434450812259")
addappid(1753980,0,"5373b843f2355df32399e1130a468df8893039961569bde75192c1be9e05f0d6")
-- setManifestid(1753980,"3263965511551036653")