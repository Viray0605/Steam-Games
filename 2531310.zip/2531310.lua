-- 2531310 Manifest and Lua created by Evan
-- The Last of Us™ Part II Remastered
-- Created: October 30, 2025 at 06:14:51 
-- Total Depots: 3
-- Total DLCs: 0
-- MAIN APPLICATION








-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2531310) -- The Last of Us Part II Remastered
addappid(2531311,0,"f7506952e736e71547c2d3c2c82959438e836c66d5b8b8f3208ccc082f60df23")
-- setManifestid(2531311,"4566212634007989287")
addappid(2531313,0,"a88758211f172f53efb57ad5c819b9d5f34b0796b44bd876639a09029e6a8089")
-- setManifestid(2531313,"4994458262959665537")
addappid(2531314,0,"3dc1a7d997476f1b4eb3a78f11af1be0d750a14719dc5d5eaeb940bcd44b74e5")
-- setManifestid(2531314,"6262322802969244361")