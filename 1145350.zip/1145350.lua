-- 1145350 Manifest and Lua created by Evan
-- Hades II
-- Created: October 28, 2025 at 06:18:54 
-- Total Depots: 3
-- Total DLCs: 0
-- MAIN APPLICATION



-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1145350) -- Hades II
addappid(1145352,0,"ff02298666a5470ddca19f89593983136f6d1727fc82957ca6b847133783b4e7")
-- setManifestid(1145352, "6961261004728985549")
addappid(1145354,0,"71f0364cb7bd2b7d7755605c7983bf2b73101a6e2e0ef6b7082d275a4650f7e5")
-- setManifestid(1145354, "3274726608137700194")
addappid(1145355,0,"67def0278f458945e71a75914c686e5bf4d3f90c8b4320795c3b78ad999afc56")
-- setManifestid(1145355, "2060204187511838131")
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2950840) -- Hades II Original Soundtrack