-- 1544020 Manifest and Lua created by Evan
-- The Callisto Protocol™
-- Created: December 29, 2025 at 01:37:04 (UTC)
-- Total Depots: 14
-- Total DLCs: 8


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION

addappid(1544020) -- The Callisto Protocol
addappid(1544021, 1, "0be23488a97872786093bd5600a1a4b684c295fc62bc297f35a6563df498fe6f") -- Depot 1544021
-- setManifestid(1544021, "1938704689332826260", 81399142838)
addappid(1544022, 1, "d88dbedb3de9c5ad528fc620aadbb5a399286edb7c458cdfb1c1609fc2239b82") -- Depot 1544022
-- setManifestid(1544022, "2253974945000192419", 2897855481)
addappid(1544023, 1, "1bc04a6c6f33362b2c454a0e8cf160249368b256a3965bc3691c309d1678e6a4") -- Depot 1544023
-- setManifestid(1544023, "2952601058967732735", 2765501723)
addappid(1544024, 1, "64e2a0a32c64b69adca6a5a94ea31f49008aeb493df398c8966d4c7598e81854") -- Depot 1544024
-- setManifestid(1544024, "7071711589262804358", 2868480293)
addappid(1544025, 1, "78880e4306350404a87c23eecb6e59d7e4eff57d9dc63a5576c1f5c1d7905625") -- Depot 1544025
-- setManifestid(1544025, "8710805714010989214", 2787742834)
addappid(1544026, 1, "476cf11a6086ca3d60dbe07b86194049e0e405dbddedbed433f875078a7a65d8") -- Depot 1544026
-- setManifestid(1544026, "1382732365015220676", 2821203170)
addappid(1544027, 1, "5e65c277d04535bff069917342a907d9ea2fc5389a8e2063e58003abd7988aee") -- Depot 1544027
-- setManifestid(1544027, "6091474570632021120", 2830891651)
addappid(1544028, 1, "622f6b97788b319d885e0e4d1e59003abf73b0cfb2293e8d264d7f39067c9bf6") -- Depot 1544028
-- setManifestid(1544028, "8455216624062883499", 2762095775)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
-- setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2005972) -- The Callisto Protocol™ - The Outer Way Skin Collection
addappid(2005983) -- The Callisto Protocol - Final Transmission
addappid(2005984) -- The Callisto Protocol - DLC 3
addappid(2006030) -- The Callisto Protocol - Retro Prisoner Weapon Skin
addappid(2015680) -- The Callisto Protocol - Season Pass
addappid(2021870) -- The Callisto Protocol - Day One Edition
addappid(2021871) -- The Callisto Protocol - Digital Deluxe Edition
addappid(2163870) -- The Callisto Protocol - Radeon Skin
addappid(2341550) -- The Callisto Protocol - Contagion Bundle
addappid(2518830) -- The Callisto Protocol - Biophage Skin
addappid(2518840) -- The Callisto Protocol - Gore Skin
addappid(2518850) -- The Callisto Protocol - Snake Skin