-- 1194630 Manifest and Lua created by Evan
-- The Dark Pictures Anthology: Little Hope
-- Created: October 25, 2025 at 01:20:23 
-- Total Depots: 2
-- Total DLCs: 0
-- MAIN APPLICATION

-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1194630) -- The Dark Pictures Anthology: Little Hope
-- MAIN APP DEPOTS
addappid(1194633,0,"c2a60fdea7b1519ad4f79cde6079b8cd3894fa5884ea554071369734d3977594") -- Depot 1194633
-- setManifestid(1194633,"2401317617118803807")
addappid(1194634,0,"2d0d066d3183f8a09ff116446a893895daeda82fbb6911588ed7ef21f4814f60") -- Depot 1194634
-- setManifestid(1194634,"7353019674043464160")