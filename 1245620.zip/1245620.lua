-- 1245620 Manifest and Lua created by Evan
-- ELDEN RING
-- Created: October 27, 2025 at 11:03:48 
-- Total Depots: 9
-- Total DLCs: 2
-- MAIN APPLICATION













-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1245620) -- ELDEN RING
addappid(1799420)
addappid(1922350)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2778590) -- ELDEN RING Shadow of the Erdtree Premium Bundle
addappid(2855530)
addappid(1896300,0,"946e5c4e2c91a3ed363efc688218994f7fa6e8fdd56aa8b5752456d3b28e0543")
-- setManifestid(1896300, "6325584622097183403")
addappid(1896320,0,"de7086b709fdfc7d151bfce5d07509fd80a6c318a21e8fb1e820db5b1cda5860")
-- setManifestid(1896320, "7913960615891263013")
addappid(2778580,0,"9f1556645ea8ef43529f920cf02a2682a6da5756b29e630ba376a0cde24e3908") -- ELDEN RING Shadow of the Erdtree
-- setManifestid(2778580, "8226581821665546770")
addappid(2855520,0,"476eca9191866d6743aa7ad82d4d7ce1fcd5e0f0613f2f4b6559635d68f8c0e3")
-- setManifestid(2855520, "4132898292665232948")
addappid(1245621,0,"5f560fca048a138487e1e634a1e60693a7ad3ae7318c31731d147f16e093f10b")
-- setManifestid(1245621, "1292635420563027963")
addappid(1245623,0,"b27090a72caa5f3cf2e1f41a81c4bc1c422a6ac277e1cd3a6f1ea68200288d4b")
-- setManifestid(1245623, "3547980754086643033")
addappid(1245624,0,"e194ce5e5f83c427743781c1708c4bce6683d5d65521059f6e4ca64a8f36f3cd")
-- setManifestid(1245624, "7017181152898342588")