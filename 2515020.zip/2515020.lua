-- 2515020 Manifest and Lua created by Evan
-- FINAL FANTASY XVI
-- Created: November 25, 2025 at 11:45:14 (UTC)
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(2515020) -- FINAL FANTASY XVI
addappid(2515021,0,"a1bc4011c581932ab613727be50494068bd3d57d59fa0f60bef081401902a046")
-- setManifestid(2515021,"8473560965998297727")
addappid(2515022,0,"3bf28fa5738f1732e7e31ca3de269b6690be6a325d2ce76da6f924ddf812b90b")
-- setManifestid(2515022,"8458672795933688766")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2886900) -- FINAL FANTASY XVI Expansion Pass
addappid(2744060) -- FINAL FANTASY XVI The Rising Tide
addappid(2744050) -- FINAL FANTASY XVI Echoes of the Fallen
addappid(3372350) -- FINAL FANTASY XVI Original Soundtrack
addappid(3372360) -- FINAL FANTASY XVI - Original DLC Soundtrack - From Spire to Sea
