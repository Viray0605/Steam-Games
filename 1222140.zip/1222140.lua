-- 1222140 Manifest and Lua created by Evan
-- Detroit: Become Human
-- Created: November 01, 2025 at 06:21:48 
-- Total Depots: 1
-- Total DLCs: 0
-- MAIN APPLICATION





-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1222140) -- Detroit: Become Human
addappid(1222141,0,"d87af32872df297ec519d0e79b6e0afc327b09048c3414622606b54efc46f519")
-- setManifestid(1222141,"7324084008489949045")