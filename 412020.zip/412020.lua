-- 412020 Manifest and Lua created by Evan
-- Metro Exodus
-- Created: November 03, 2025 at 02:10:51 (UTC)
-- Total Depots: 7
-- Total DLCs: 2
-- MAIN APPLICATION


addappid(412020) -- Metro Exodus
addappid(228987)
-- setManifestid(228987,"4302102680580581867")
addappid(412021,0,"f06003bf9aba2630c97f3f84b80f14067b0df94fb9bfabadcbaea93e1ae4c6f7")
-- setManifestid(412021,"8743909117511884672")
addappid(412022,0,"fdaa0cc6fe8207b1742e3d1fe9b0c62fc848da589cba441eef409d816d6aa775")
-- setManifestid(412022,"4169096906348758341")
addappid(889922,0,"8bed7c94e8395e6a090d72ce60b7048ef9995126be4d7c04896c25ed74382608")
-- setManifestid(889922,"2273948263506713647")
addappid(889923,0,"2853b589418e3e2cdbe78e9e851ac23e54a9f14bef73641a0309f59f4d4f37d1")
-- setManifestid(889923,"1970836693290980708")
addappid(889920,0,"0c8376c99ff46438fef56701e400b882822dd57b5d292398e222228f628849a6") -- Metro Exodus - The Two Colonels
-- setManifestid(889920,"361436782434919800")
addappid(889921,0,"ba6a1b0ca33f2370d28d58adc6b53ed79d5fb88d1931130c96ecf95df0530ae2") -- Metro Exodus - Sam's Story
-- setManifestid(889921,"181613428803252911")
addappid(412023,0,"2d1188fda4fe6c142425d0a9c34f0e6353e5b09eaf0f9967995ecc2948af10f8")
-- setManifestid(412023,"4901698992981806692")
addappid(412024,0,"45161252e073acc402c8cb3c9227484c10aa4f205f1e709294d2c220f6241ded")
-- setManifestid(412024,"2770016577399373364")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(924220) -- Metro Exodus Expansion Pass
