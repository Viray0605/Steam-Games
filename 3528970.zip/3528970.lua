-- 3528970's Lua and Manifest Created by Morrenus
-- Unmourned
-- Created: November 29, 2025 at 05:47:37 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3528970) -- Unmourned
-- MAIN APP DEPOTS
addappid(3528971, 1, "ea56d857e3f28b76a141ec7e2254ea462046bc96d72b511000eed1a40bfcba0b") -- Depot 3528971
setManifestid(3528971, "3961093937174406863", 22586726063)