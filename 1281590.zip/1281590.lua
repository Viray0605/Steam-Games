-- 1281590 Manifest and Lua created by Evan
-- The Dark Pictures Anthology: House of Ashes
-- Created: October 25, 2025 at 01:20:52 
-- Total Depots: 2
-- Total DLCs: 0
-- MAIN APPLICATION

-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1281590) -- The Dark Pictures Anthology: House of Ashes
-- MAIN APP DEPOTS
addappid(1281591,0,"30227bc236f755706519e5ac1540f31eac52e838767d82935eb85cde675e6409") -- Depot 1281591
-- setManifestid(1281591,"6253558574274131850")
addappid(1281594,0,"28b51e4e5d74c2dba5007400963dfadea9ec1c90c0da35c6ebbe5399c769dff1") -- Depot 1281594
-- setManifestid(1281594,"173647823449055481")