-- 379430 Manifest and Lua created by Evan
-- Kingdom Come: Deliverance
-- Created: November 14, 2025 at 07:05:34 (UTC)
-- Total Depots: 5
-- Total DLCs: 8

-- MAIN APPLICATION




addappid(379430) -- Kingdom Come: Deliverance
addappid(228986)
-- setManifestid(228986,"8782296191957114623")
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(379432,0,"108f95cce2562576671a8d1deb159b583397b664cafabd96f622beaae2a38655")
-- setManifestid(379432,"426485591477717928")
addappid(379433,0,"b73a679f54e714c4f1faf2c054cb3acaf90fcdd998e96984742b9f5f20d5325e")
-- setManifestid(379433,"5353900087755850263")
addappid(379431,0,"28025aa521351af4da4b05336ce0cdeb467cf54ab15af771b6e96e777e6e11ef")
-- setManifestid(379431,"3231236415084706454")
addappid(836890,0,"7e4b67dfff0691c120ae20411dd923d92fe00e434fc66529e528c431dcacf0ef") -- Kingdom Come: Deliverance – HD Texture Pack
-- setManifestid(836890,"1375049741468394017")
addappid(836900,0,"d131517918735f795946cf9898da1e5f69df47f9e2f4a6f572f74ab375f3152d") -- Kingdom Come: Deliverance – HD Sound Pack
-- setManifestid(836900,"6125976842225591303")
addappid(836910,0,"fde946d787d448a9ad59c6b49c4c8ed56da692d161669d585a82129d4c74be1e") -- Kingdom Come: Deliverance – HD Voice Pack English
-- setManifestid(836910,"1961281874941694896")
addappid(836920,0,"abb26620bd532d9519f5c3359a4995bd7def223ec7ddef791fe0b487ecf6eff3") -- Kingdom Come: Deliverance – HD Voice Pack German
-- setManifestid(836920,"2096891146739122223")
addappid(836930,0,"479474ba710c10d7b528343e0471cb4e979ad174ef2fefe437dbc0c0f1da8b43") -- Kingdom Come: Deliverance – HD Voice Pack French
-- setManifestid(836930,"4537521641197841292")
addappid(921950,0,"7a9065cf0a6bab53fc81761cd1c3ccdd67e1516403d4a59d0a272de7b0c876ff") -- Kingdom Come: Deliverance – The Amorous Adventures of Bold Sir Hans Capon
-- setManifestid(921950,"3621959063097269656")
addappid(977420,0,"aafa5c0edc670ba1c9b40669ccbff37939d12a3484df559cda3a4fa671fdf72f") -- Kingdom Come: Deliverance – Band of Bastards
-- setManifestid(977420,"4585083368905346922")
addappid(1033890,0,"4e8ad98af79c5565ecb6850e4f7a582e875c939630f61980a886f6a2e9168c81") -- Kingdom Come: Deliverance – A Woman's Lot
-- setManifestid(1033890,"3972128807530539973")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(883150) -- Kingdom Come: Deliverance – From the Ashes
addappid(768530) -- Kingdom Come: Deliverance – Treasures of The Past
addappid(1052530) -- Kingdom Come: Deliverance – OST Atmospheres & Additionals
addappid(794220) -- Kingdom Come: Deliverance – OST Essentials
addappid(801980) -- Kingdom Come: Deliverance – Artbook
