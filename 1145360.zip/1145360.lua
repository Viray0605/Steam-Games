-- 1145360 Manifest and Lua created by Evan
-- Hades
-- Created: November 17, 2025 at 01:32:46 (UTC)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION



addappid(1145360) -- Hades
-- setManifestid(228988,"6645201662696499616")
-- setManifestid(229006,"1784011429307107530")
addappid(1145361,0,"e7db1a4f43363b9d751ed9e888334353425704ea0db26c8434015e516a482f4d")
-- setManifestid(1145361,"5173085471687919135")
addappid(1145363,0,"b88219eb2aee190d115e532ef9feea08c69bbc53bb1f959a2c48f3739f871b31")
-- setManifestid(1145363,"2572656066874346283")
addappid(1145364,0,"c70c6707a01507e124d35ac0e1644ee6210f383a1ae759aa252478cbd1ca7e0e")
-- setManifestid(1145364,"6896671991921324741")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1206340) -- Hades Original Soundtrack
