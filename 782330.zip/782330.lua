-- 782330 Manifest and Lua created by Evan
-- DOOM Eternal
-- Created: November 24, 2025 at 08:58:40 (UTC)
-- Total Depots: 9
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(782330) -- DOOM Eternal
-- setManifestid(228988,"6645201662696499616")
-- setManifestid(228990,"1829726630299308803")
addappid(782332,0,"50c0780a4d2fe21b3bbdf3e70f7705e07544725ddb3b65c32580d2f8c8652801")
-- setManifestid(782332,"3719882324993485765")
addappid(782333,0,"ae331c10946ec0147a027c970cc531ce101105b4a761c835d01d500a02f15cf9")
-- setManifestid(782333,"7790151103401207847")
addappid(782334,0,"a444c49bffe4e0ea2fde35c1cf7ada5b2282711c72fcd2ac88f89abbe40f61d7")
-- setManifestid(782334,"2305285962735833965")
addappid(782335,0,"3b4cff3ce45f5fe2f10c0ec4ddd80ccc514fb48df6c0cce946bfba8f9e138400")
-- setManifestid(782335,"4277233946804126868")
addappid(782338,0,"5bed7bb7b23d1d00ec8ec0db60fa7b92f4cbfe02e12dbc481c89c0b627933216")
-- setManifestid(782338,"8642366102070535855")
addappid(782336,0,"8e8398764c2ed958096c29c49abad7be5160a272889979f6de1d38d2e3f8b39c")
-- setManifestid(782336,"3442068440108528889")
addappid(782337,0,"173e7ffd69ef2f81a69d99858c80cd6947693b247645da2a3caa3bb7593c4c61")
-- setManifestid(782337,"7595167059955801744")
addappid(782339,0,"eda659b514b48a17be8e2619052fae93c7b37578ee6bfc3fd648a8844246e86b")
-- setManifestid(782339,"5334830772540664008")
addappid(1098294,0,"4853f1060dba902f3a474dbd6710c8e8f8db4fbec981d3fc90da7dc51ec85d62")
-- setManifestid(1098294,"6180500623984810207")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1098292) -- DOOM Eternal: The Ancient Gods - Part One
addappid(1098293) -- DOOM Eternal: The Ancient Gods - Part Two
addappid(1098300) -- DOOM Eternal: The Rip and Tear Pack
addappid(1749101) -- DOOM Eternal: Series Five Cosmetic Pack
addappid(1749103) -- DOOM Eternal: Series Seven Cosmetic Pack
addappid(1749102) -- DOOM Eternal: Series Six Cosmetic Pack
addappid(1749100) -- DOOM Eternal: Series Four Cosmetic Pack
addappid(1626003) -- DOOM Eternal: Cosplay Slayer Master Collection Cosmetic Pack
addappid(1626001) -- DOOM Eternal: Series Three Cosmetic Pack
addappid(1626002) -- Mullet Slayer Master Collection Cosmetic Pack
addappid(1626000) -- DOOM Eternal: Series Two Cosmetic Pack
addappid(1460020) -- DOOM Eternal: Series One Cosmetic Pack
addappid(1460021) -- DOOMicorn Master Collection Cosmetic Pack
