-- 2183900 Manifest and Lua created by Evan
-- Warhammer 40,000: Space Marine 2
-- Created: November 18, 2025 at 09:03:13 (UTC)
-- Total Depots: 1
-- Total DLCs: 16

-- MAIN APPLICATION


-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2183900) -- Warhammer 40,000: Space Marine 2

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2486150) -- Warhammer 40,000: Space Marine 2 - Macragge’s Chosen DLC
addappid(2792140) -- Warhammer 40,000: Space Marine 2 - Ultramarines Champion Pack
addappid(2792150) -- Warhammer 40,000: Space Marine 2 - Ultramarines Cosmetic Pack
addappid(2792170) -- Warhammer 40,000: Space Marine 2 - Dark Angels Chapter Pack
addappid(2792180) -- Warhammer 40,000: Space Marine 2 - Space Wolves Chapter Pack
addappid(2792190) -- Warhammer 40,000: Space Marine 2 - White Scars Chapter Pack
addappid(2792280) -- Warhammer 40,000: Space Marine 2 - Season Pass
addappid(3274400) -- Warhammer 40,000: Space Marine 2 - Raven Guard Cosmetic Pack
addappid(3274410) -- Warhammer 40,000: Space Marine 2 - Salamanders Champion Pack
addappid(3274430) -- Warhammer 40,000: Space Marine 2 - Imperial Fists Champion Pack
addappid(3274440) -- Warhammer 40,000: Space Marine 2 - Blood Angels Cosmetic Pack
addappid(3871320) -- Warhammer 40,000: Space Marine 2 - Season Pass 2
addappid(3871330) -- Warhammer 40,000: Space Marine 2 - Black Templars Champion Pack
addappid(3871340) -- Warhammer 40,000: Space Marine 2 - Imperial Fists Cosmetic Pack
addappid(3202690,0,"00c47f82b08192958b11307abb87c755003eb8dfae75063373e379c296b26083") -- Warhammer 40,000: Space Marine 2 - 4K Texture Pack
-- setManifestid(3202690,"994646476768083300")
addappid(3212040,0,"e3818ce0f203d78eed2647e6364bd19a702fd8d7a01230f77a038e0fd26b0ffb") -- Warhammer 40,000: Space Marine 2 - The Art and Making of
-- setManifestid(3212040,"7457655780363166458")
addappid(2183901,0,"8df236a6a5084039477362b31157e7e0eb66554a744762d6782c544ab64d0c4e")
-- setManifestid(2183901,"663329678622764991")
addappid(3212020) -- Warhammer 40,000: Space Marine 2 - Original Soundtrack
