-- 1790600 Manifest and Lua created by Evan
-- DRAGON BALL: Sparking! ZERO
-- Created: November 05, 2025 at 07:04:05 (UTC)
-- Total Depots: 3
-- Total DLCs: 11

-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link : https://guns.lol/f1uxin


-- MAIN APPLICATION 



addappid(1790600) -- DRAGON BALL: Sparking! ZERO

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2957460) -- DRAGON BALL: Sparking! ZERO Pre-Order Pack
addappid(2957470) -- DRAGON BALL: Sparking! ZERO Ultimate Upgrade Pack
addappid(2957500) -- DRAGON BALL: Sparking! ZERO Victory Pack
addappid(2957510) -- DRAGON BALL: Sparking! ZERO Martial Arts Pack
addappid(2957520) -- DRAGON BALL: Sparking! ZERO Season Pass
addappid(2963440)
addappid(2963450)
addappid(3310650) -- DRAGON BALL: Sparking! ZERO HERO OF JUSTICE Pack
addappid(3456600) -- DRAGON BALL: Sparking! ZERO - Dragon Ball DAIMA: Character Pack 1
addappid(3456610) -- DRAGON BALL: Sparking! ZERO - Dragon Ball DAIMA: Character Pack 2
addappid(3693250) -- DRAGON BALL: Sparking! ZERO - Shallot (DRAGON BALL LEGENDS)
addappid(2957480,0,"a8bbd2bdc3022cc2edc229e300b7583436b29d0e469662a8a277cf066798aa9f") -- DRAGON BALL: Sparking! ZERO Anime Music Pack 1
-- setManifestid(2957480,"8386927810532837243")
addappid(2957490,0,"1b1f85ab25eb92147de8a0c1531d9ed57f3e01cfd46c9bb37be377251c2d24cd") -- DRAGON BALL: Sparking! ZERO Anime Music Pack 2
-- setManifestid(2957490,"9060747264604927849")
addappid(1790601,0,"0721a07eb97ba7b4e59e31606ae9f0d67c66309cc467c5da1aa79a924c34e7d8")
-- setManifestid(1790601,"6229403258236573958")