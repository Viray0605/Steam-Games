-- 1462040 Manifest and Lua created by Evan
-- FINAL FANTASY VII REMAKE INTERGRADE
-- Created: October 29, 2025 at 03:44:11 
-- Total Depots: 3
-- Total DLCs: 0
-- MAIN APPLICATION





-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1462040) -- FINAL FANTASY VII REMAKE INTERGRADE
addappid(1462041,0,"4e299a23f9a767cbb2ea9a71d2fd2334b46e66904c51f2478e1b54994e7d33a9")
-- setManifestid(1462041, "2823103069660518704")
addappid(1462042,0,"ac6881e562951d6369653f3e05bfbb32cb022208f25a950fd31e5045afe31498")
-- setManifestid(1462042, "9009674327124226670")
addappid(1462043,0,"85dd87a3f14448b8659faa0acf1ec19c4213ea1096601adec258a00910b31cbb")
-- setManifestid(1462043, "3277734470947023189")
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3365650) -- FINAL FANTASY VII REMAKE INTERGRADE FINAL FANTASY VII REMAKE Original Soundtrack
addappid(3365670) -- FINAL FANTASY VII REMAKE INTERGRADE FINAL FANTASY VII REMAKE Original Soundtrack Plus
addappid(3365690) -- FINAL FANTASY VII REMAKE INTERGRADE Original Soundtrack