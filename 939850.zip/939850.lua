-- 939850 Manifest and Lua created by Evan
-- The Dark Pictures Anthology: Man of Medan
-- Created: October 25, 2025 at 01:21:21 
-- Total Depots: 3
-- Total DLCs: 0
-- MAIN APPLICATION

-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(939850) -- The Dark Pictures Anthology: Man of Medan
-- MAIN APP DEPOTS
addappid(939851,0,"52870eaa88e4dc0373d6136c84ca9cabfc5e45c197916e1f1a777d3aabe53e66") -- Depot 939851
-- setManifestid(939851, "2233225956230312354")
addappid(939852,0,"2daad047203d2dc13cb81e42a049520aca137a4309b78eb78b029182d5cfd1d2") -- Depot 939852
-- setManifestid(939852, "45510479311498930")
addappid(939855,0,"939fae16bccf377c3682c43e18059e7c887bd39106cec6f5fcb10228adfe4683") -- Depot 939855
-- setManifestid(939855, "5424050174599472496")