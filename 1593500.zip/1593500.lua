-- 1593500 Manifest and Lua created by Evan
-- God of War
-- Created: October 26, 2025 at 03:59:24 
-- Total Depots: 1
-- Total DLCs: 0
-- MAIN APPLICATION



-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1593500) -- God of War
addappid(1593501,0,"77f7390a115063bccc41240f71e0bf27d42c6a7c0424657756fe3f99f26a287a")
-- setManifestid(1593501, "2535153423663269664")