-- 1190970 Manifest and Lua created by Evan
-- House Flipper 2
-- Created: November 05, 2025 at 02:44:58 (UTC)
-- Total Depots: 1
-- Total DLCs: 1
-- MAIN APPLICATION




addappid(1190970) -- House Flipper 2
addappid(1190971,0,"a6202777d416dcf4d2f36cc5f7a69f90cca6e1bfbde6e27eaa4e97e86c7d3196")
-- setManifestid(1190971,"9077091668481121453")
addappid(2649200,0,"75c666e7e7f011eddb178036bbb4b16446378ef945ecf6811f32e2a4f96bfcc7") -- House Flipper 2 - Supporter Pack
-- setManifestid(2649200,"2894455407820860002")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3672960) -- House Flipper 2 - Scooby-Doo DLC
addappid(3363370) -- House Flipper 2 - Co-op DLC
addappid(3680100) -- House Flipper 2 - Pets DLC
