-- 1577120 Manifest and Lua created by Evan
-- The Quarry
-- Created: November 18, 2025 at 09:03:26 (UTC)
-- Total Depots: 3
-- Total DLCs: 3

-- MAIN APPLICATION


-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1577120) -- The Quarry

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1877110) -- The Quarry – Horror History Visual Filter Pack
addappid(1877111) -- The Quarry – Deluxe Bonus Content Pack
addappid(1891950)
addappid(2101870) -- The Quarry - ‘50s Throwback Character Outfits
addappid(1523211,0,"6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
-- setManifestid(1523211,"5488617169383930545")
addappid(1577122,0,"d1f173e0a675ae53ba562864c36961f17e2f532af0acd7764099896fe7852d6d")
-- setManifestid(1577122,"3441814442032017627")