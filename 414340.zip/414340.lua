-- 414340 Manifest and Lua created by Evan
-- Hellblade: Senua's Sacrifice
-- Created: November 25, 2025 at 11:47:17 (UTC)
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(414340) -- Hellblade: Senua's Sacrifice
-- setManifestid(228984,"2547553897526095397")
-- setManifestid(228985,"3966345552745568756")
-- setManifestid(228986,"8782296191957114623")
-- setManifestid(228990,"1829726630299308803")
addappid(414341,0,"b52b49b1aa5b2931a20af4d509e604d4e96a00895d7e75bf04acaffa573ebe09")
-- setManifestid(414341,"3390494925423867663")
addappid(626750,0,"da8b16e5fa6895ec08a5589fd5b68f1adfe6f1f24c7120e06dc2fdcda3219b4a")
-- setManifestid(626750,"7617494232712978521")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(862810) -- Hellblade: Senua's Sacrifice Original Soundtrack
