-- 1237320 Manifest and Lua created by Evan
-- Sonic Frontiers
-- Created: October 28, 2025 at 03:19:05 
-- Total Depots: 1
-- Total DLCs: 0
-- MAIN APPLICATION





addappid(1237320) -- Sonic Frontiers
-- setManifestid(228988, "6645201662696499616")
-- setManifestid(228990, "1829726630299308803")
addappid(1237321,0,"9c57e01f36d7bf7a77b07678b08a0e690d785dfbcd9a421ae1fc2157741b5ccd")
-- setManifestid(1237321, "2773324310090316887")
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2089730) -- Sonic Frontiers: Monster Hunter Collaboration Pack
addappid(2089733) -- Sonic Frontiers: Holiday Cheer Suit
addappid(2089840) -- Sonic Frontiers: Sonic Adventure 2 Shoes