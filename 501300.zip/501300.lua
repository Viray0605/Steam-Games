-- 501300 Manifest and Lua created by Evan
-- What Remains of Edith Finch
-- Created: December 29, 2025 at 01:37:48 (UTC)
-- Total Depots: 3
-- Total DLCs: 0


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION

addappid(501300) -- What Remains of Edith Finch
addappid(501301, 1, "957d96d75b0602ec2946f46e298b1c9179a719d977dd1e80d037e13f9c4a7f7d") -- WRoEF Win64 Content
-- setManifestid(501301, "3230192986366154672", 2540778487)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
-- setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(629930) -- What Remains of Edith Finch - Original Soundtrack
