-- 3868310's Lua and Manifest Created by Morrenus
-- My Wife Threw Out My Card Collection (So I Bought a Dump to Find Them All) ⭐
-- Created: November 28, 2025 at 07:08:26 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3868310) -- My Wife Threw Out My Card Collection (So I Bought a Dump to Find Them All) ⭐
-- MAIN APP DEPOTS
addappid(3868311, 1, "30fd117a149e253dd870c9858f3c3e8b0de11ca7884c11a1617a669b98d42645") -- Depot 3868311
setManifestid(3868311, "5699134428145958289", 1087107754)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4172780) -- My Wife Threw Out My Card Collection (So I Bought a Dump to Find Them All)  - Supporter Pack