-- 1340990 Manifest and Lua created by Evan
-- Rise of the Ronin
-- Created: November 18, 2025 at 03:13:21 (UTC)
-- Total Depots: 10
-- Total DLCs: 0

-- MAIN APPLICATION




-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1340990) -- Rise of the Ronin
addappid(228989)
-- setManifestid(228989,"550968249685141759")
addappid(1340995,0,"e57b64d9b5f9e584a87a9832529c0e1f901f699e690b4b5637fec2b2e1fbf2aa")
-- setManifestid(1340995,"1876216873872086392")
addappid(1340996,0,"2aca517d8dece95e0cbfce99e8e6b937dd56dee06fc84b510bcfe0fa09538d9d")
-- setManifestid(1340996,"3841686798722160883")
addappid(1340997,0,"37138487eef65143ea189a388085037e84de8519cef8b35cf5486474b5df15d4")
-- setManifestid(1340997,"2331755264652654819")
addappid(1340991,0,"6fdac6ccd9ebadf5c61e1c34ec225a8bc687cab591d28cc5ade262e9a65ae393")
-- setManifestid(1340991,"5032043067359059522")
addappid(1340992,0,"7c7e86cec8a1f874213799a3eb2db858af7a8e28c72d7792330cc7b28f580793")
-- setManifestid(1340992,"8097777051056268960")
addappid(1340993,0,"50234d9ac0cda0a23d385d3c086560656cc037de4dcb3d743e960f416ed5c69d")
-- setManifestid(1340993,"9075053198374038770")
addappid(1340994,0,"747729b8ffcd2e18673252e55284cc050dbecbff88ab7ef91b69cd71d941084f")
-- setManifestid(1340994,"7767196483143147196")
addappid(1340998,0,"7e685022588dcde7a3b5ee6627e0a250e8641a8bbd123bf7377b2e9e990c42fe")
-- setManifestid(1340998,"8952393605010619144")
addappid(1340999,0,"bb4b2b9bca194610993a7f32ee52f074460b0d0b54fb37099580e2d512e35728")
-- setManifestid(1340999,"9058506243337526886")