-- 4149960's Lua and Manifest Created by Morrenus
-- Dead Feed
-- Created: December 05, 2025 at 22:10:52 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4149960) -- Dead Feed
-- MAIN APP DEPOTS
addappid(4149961, 1, "29ed388e8f6249143df92e3910e1e00782133012aa9f0bc790ae81709caea83b") -- Depot 4149961
setManifestid(4149961, "6716629289967175326", 3495937094)