-- 413150 Manifest and Lua created by Evan
-- Stardew Valley
-- Created: November 28, 2025 at 06:18:17 (UTC)
-- Total Depots: 3
-- Total DLCs: 0


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION




addappid(413150) -- Stardew Valley
addappid(413151,0,"ff71699a17787b798d901cb27398556eb69a498b690b4392b2ffedcacc1019ff")
-- setManifestid(413151,"4278718763097142923")
addappid(413152,0,"c65e7919242bdcb29efd9551af381e9b6f5d828ac7382cec83f1d8459aaf3fdf")
-- setManifestid(413152,"2618652301291810021")
addappid(413153,0,"d1e04015717ef68e43064bd29a027c3309b47bd156d0494c7d4dff56a971e3c7")
-- setManifestid(413153,"6005910083361727734")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(440820) -- Stardew Valley Soundtrack
