-- 2124490 Manifest and Lua created by Evan
-- SILENT HILL 2
-- Created: October 26, 2025 at 08:38:55 
-- Total Depots: 1
-- Total DLCs: 0
-- MAIN APPLICATION








addappid(2124490) -- SILENT HILL 2
addtoken(2124490,"2486523437417765568")
-- setManifestid(228989, "550968249685141759")
-- setManifestid(228990, "1829726630299308803")
addappid(2124491,0,"1a14569bdc22983489a37bb81ed420c6230f43e84548d0ec0d4a3e9687861955")
-- setManifestid(2124491, "4138456104249046245")