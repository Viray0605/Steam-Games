-- 1583230 Manifest and Lua created by Evan
-- High On Life
-- Created: November 11, 2025 at 08:00:07 (UTC)
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION




addappid(1583230) -- High On Life

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2447000) -- High On Life: High On Knife
addappid(1583231,0,"a1246164a71713be03e1d57a313af03ac5bbde4a6a16962178bce5f74be271e4")
-- setManifestid(1583231,"4739388032191335402")