-- 1259420 Manifest and Lua created by Evan
-- Days Gone
-- Created: November 18, 2025 at 11:20:24 (UTC)
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION


-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1259420) -- Days Gone
addappid(1259421,0,"3a92a76d80b16038abe5b2831f554a22120535ab039dbde663a70c8b52afe11b") 
-- setManifestid(1259421,"9008749683399927967")
addappid(1259422,0,"95e707b118a213e71a3e7ba7a6ee3a6af3e545fb87206f8219cf7a415c359231")
-- setManifestid(1259422,"9075941046550830080")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3238470) -- Days Gone - Broken Road DLC
