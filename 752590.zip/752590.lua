-- 752590 Manifest and Lua created by Evan
-- A Plague Tale: Innocence
-- Created: November 20, 2025 at 03:05:06 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION



addappid(752590) -- A Plague Tale: Innocence
-- setManifestid(228987,"4302102680580581867")
addappid(752591,0,"31c0eb1a38b3926e0e589c25300225886ac653a8415d3612864cd26664681460")
-- setManifestid(752591,"476939438164423828")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(967380) -- A Plague Tale: Innocence - Coats of Arms DLC
