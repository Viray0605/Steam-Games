-- 1902960 Manifest and Lua created by Evan
-- AppID 1902960
-- Created: November 21, 2025 at 12:07:50 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(1902960) -- AppID 1902960
-- setManifestid(228989,"3514306556860204959")
-- setManifestid(228990,"1829726630299308803")
addappid(1902961,0,"abad4c4c537119525145d83f5b7fe9761125627d17fc04758be2de4d40de12ed")
-- setManifestid(1902961,"6409180190415452819")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3500970) -- Lost Records: Bloom & Rage Soundtrack
