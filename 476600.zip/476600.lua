-- 476600 Manifest and Lua created by Evan
-- Call of Duty®: WWII
-- Created: October 29, 2025 at 12:15:23 
-- Total Depots: 6
-- Total DLCs: 0
-- MAIN APPLICATION










addappid(476600) -- Call of Duty®: WWII
-- setManifestid(228986, "8782296191957114623")
-- setManifestid(228990, "1829726630299308803")
addappid(476601,0,"831cdecf19668b10b3209e2889d22d39db73940b21ac18a35007bf587bf931cf")
-- setManifestid(476601, "1545824956507683106")
addappid(476602,0,"613f95c421e8081508651a80293faf846ea81e6f1e1a5c27398220ce12d6e2cb")
-- setManifestid(476602, "3688161870357795857")
-- setManifestid(476623, "2715207186595524184")
-- setManifestid(476624, "1563345585010965365")
-- setManifestid(476625, "438552769716313064")
-- setManifestid(476626, "9199603757016024389")
-- setManifestid(476627, "237148457619544546")
-- setManifestid(476628, "1603528379199405449")
-- setManifestid(476629, "1306356557700383733")
-- setManifestid(476630, "24454041969172048")
-- setManifestid(476631, "259314676018769709")
-- setManifestid(476632, "3177361275812839742")
-- setManifestid(476633, "3643356666802659610")
-- setManifestid(476634, "589337432719466650")
-- setManifestid(476635, "7372176855409048609")
-- setManifestid(476636, "6956787469155296651")
addappid(476604,0,"9d96074527f4d14f2ae748dc241d6c5a08ff8a1682b022128aca9a5e96479503")
-- setManifestid(476604, "4157823044600597285")
addappid(476603,0,"ac9dcb534d5b6076fc179a3038eb8ad8aa079fa1acbf3e5db83f0d5413b97c14")
-- setManifestid(476603, "765926368879116795")
addappid(476606,0,"4b7da74018117af93f3b22f8d7d146f9b3220ec37bdfb3ee8a959bbee51d6b1f")
-- setManifestid(476606, "361687800680072742")
addappid(476605,0,"dbac9cb02a7787a7511ff155d3a36b55a44cfcdc2b4444fa0f38965f531f57a5")
-- setManifestid(476605, "317554550655629178")
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(683100) -- Call of Duty®: WWII - Season Pass
addappid(848790) -- Call of Duty®: WWII - Call of Duty™ Endowment Fear Not Pack
addappid(729160) -- Call of Duty®: WWII - Call of Duty™ Endowment Bravery Pack