-- 1466060 Manifest and Lua created by Evan
-- Tainted Grail: The Fall of Avalon
-- Created: November 06, 2025 at 04:48:20 (UTC)
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION



-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1466060) -- Tainted Grail: The Fall of Avalon
addappid(1466062,0,"b164844c9d1dcef4202a397a747eff0fc24b75b5553e21bebbd7e86042d94bca")
-- setManifestid(1466062,"3969471177465141687")
addappid(3687050,0,"8a5843ffcee408b2a16680531955ed57dd20d577be56ebb42d7c99dd653a3b2e") -- Tainted Grail: The Fall of Avalon - Supporters Pack
-- setManifestid(3687050,"3877787421677591921")