-- 534380 Manifest and Lua created by Evan
-- Dying Light 2 Stay Human: Reloaded Edition
-- Created: November 14, 2025 at 03:16:09 (UTC)
-- Total Depots: 50
-- Total DLCs: 14


-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION 



addappid(534380) -- Dying Light 2 Stay Human: Reloaded Edition
addappid(534380,0,"da5060467c4b9199432fb5d9ba41ae2896a9c4a4705bc8e8f426155dc8efae83") -- Dying Light 2 Stay Human: Reloaded Edition
addappid(1537620)
addappid(1537621)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1537622) -- Dying Light 2 Stay Human: Goodies Pack—Arts
addappid(1537623)
addappid(1864100)
addappid(1864200)
addappid(1864230)
addappid(1864240)
addappid(1864250)
addappid(1864260)
addappid(1888510) -- Dying Light 2 - Soundtrack
addappid(1937530)
addappid(1937531)
addappid(2108090)
addappid(2156750) -- Dying Light 2 Stay Human: Dying Laugh Bundle
addappid(2210190) -- Dying Light 2 Stay Human: Nutcracker Bundle
addappid(2269810) -- Dying Light 2 Stay Human: Rais Bundle
addappid(2269820) -- Dying Light 2 Stay Human: Brecken Bundle
addappid(2330980) -- Dying Light 2 Stay Human:  Chicken Bundle
addappid(2370460) -- Dying Light 2 Stay Human: Rahim Bundle
addappid(2370480) -- Dying Light 2 Stay Human: Gunslinger Bundle
addappid(2370700) -- Dying Light 2 Stay Human: Post-apo Bundle
addappid(2370710) -- Dying Light 2 Stay Human: Nightrunner Bundle
addappid(2400900)
addappid(2456710) -- Dying Light 2 Stay Human: Hakon Bundle
addappid(3453200) -- Dying Light 2 Stay Human: G.R.E. Hazmat Bundle
addappid(3818860)
addappid(3833090) -- Dying Light 2 - 1500 DLP One-off Offer
addappid(534386,0,"0f124b03d74178f173d00c78c84573dc7cef743f0d0835edea668a5ed3ba116e")
-- setManifestid(534386,"1344544806272816313")
addappid(1741805,0,"7fd30a7a706af1dc2c94010cf7486ebf1d49af69f2aebe663075b6810d1dd527")
-- setManifestid(1741805,"4838818544371714425")
addappid(1263581,0,"b7e959a2f431a626db99f0f9d3e4f9da7b5f725308214738c3f93ecc70aec314")
-- setManifestid(1263581,"6253858909356246486")
addappid(534381,0,"fec776617825a7f3e61dd191f407bd23c6f60ba1056a506f1facb4fd74d9f7e2")
-- setManifestid(534381,"7025184737709540738")
addappid(534382,0,"cf933660206b892b3d32060682d4063e7a42482428b1cbb3f0b8fed43cdfee45")
-- setManifestid(534382,"802374179886655501")
addappid(534383,0,"1a2b6e67c39a9803c80ab38c1be8b25b112ae32eaa1872b6cd42db109049e007")
-- setManifestid(534383,"7120070796197620571")
addappid(534384,0,"b5e4f819a4ac1b9e78bca8293db8428a4eea8a95b6913fc32842010060db425e")
-- setManifestid(534384,"5341367238646277760")
addappid(534385,0,"c7a22e2cab3e656efbdaceb8e2a7b76748c1790517faf3283beaa2cf761f5dc0")
-- setManifestid(534385,"3161415210373875426")
addappid(534387,0,"d3fcdef424d1ec4c1a72bc78a8ae5364b74a5abd23ef7cbeca64996cad28b24b")
-- setManifestid(534387,"5923901878761996089")
addappid(534388,0,"9af548a883576aa8eb98d69ceef4d0a50b7e5beebe14744e078cd2f47ace909b")
-- setManifestid(534388,"3270090956763118835")
addappid(534389,0,"3e6c48fa5a81522f18e7633fa89b6ea95f05d991c626ee9ceaebecf711cd6e72")
-- setManifestid(534389,"9119221394124534377")
addappid(1741780,0,"56a0e9c235e8305b7e1f1e722252b52918ea0003a341b5901c42ec0d39cd449c")
-- setManifestid(1741780,"8156203946833876789")
addappid(1741781,0,"42678fed970f2d33723e75c88c27c4d19278d40ddbea2be652c02d7dfb41404f")
-- setManifestid(1741781,"5520855431963099234")
addappid(1741782,0,"26d52711c65b1d4c96eb06fb7fba2a68e80984a9828a074bf8a5384c16e86433")
-- setManifestid(1741782,"4235920198176569072")
addappid(1741783,0,"f1fd93f6cd43dbde9dfecda6beceaec208b0c3842cd34ded16b3f31ae7984f0b")
-- setManifestid(1741783,"2805818940378178315")
addappid(1741784,0,"56ca0a485646ce4d5fb8163100b5f62610f743c214fabd9133f57b3dc3720d44")
-- setManifestid(1741784,"7416074613764999877")
addappid(1741785,0,"377954647d348be60b76ce49cae9b13763ad66aba3ce9ec5e1b0ba1f9f6c7a49")
-- setManifestid(1741785,"7946953918491871241")
addappid(1741786,0,"19a6afcb6a47753b8b8d5f8a0febea931845a56103db941a3cedc57fa4fa3632")
-- setManifestid(1741786,"5191813724382444489")
addappid(1741787,0,"a2dcee88dfd62b92c47a6260dd083eefd70bb504b41012881ef45e10d3ef31e4")
-- setManifestid(1741787,"6545046833002776327")
addappid(1741788,0,"5647c59ff805db90b39f2286a138774c318579addeb0ae3cd67cb37be8391794")
-- setManifestid(1741788,"723546204821785234")
addappid(1741789,0,"d45069f6f74b78a88a6d5bd30c9e7e56cb00c84e80957adc473e0815581f8ca5")
-- setManifestid(1741789,"8955942730260346905")
addappid(1741790,0,"ffb3557cf402c7a2847a17a705d05cc02b1c921cedb1a4e33c0965c3ef3b8ead")
-- setManifestid(1741790,"9060667572210464664")
addappid(1741791,0,"83833d3a3c1d59757bd4fd32fe79b0498cfdbd4ba1a4c770319bf58734d3220c")
-- setManifestid(1741791,"8570838396941877672")
addappid(1741792,0,"eec928bf10da86f55bc03800c52b9292406c09c72e9d5ef99373c846e960f5ca")
-- setManifestid(1741792,"4343221204854113704")
addappid(1741793,0,"4dd7ff0cb01db2bf5c574054353078bef596a1cd611a8268bd5a023c65022278")
-- setManifestid(1741793,"2027645059936077690")
addappid(1741794,0,"17d125330d6f175e6c28c56630312084fe07a44a06bcbffc530c3f590d01667c")
-- setManifestid(1741794,"5995236779363049351")
addappid(1741795,0,"8b0095c3dc40776199884af8ac54987c23277a352c03f79acdbf51eea7ef6191")
-- setManifestid(1741795,"4952609333908441147")
addappid(1741796,0,"6d55d6c6f95126badb8fc4d39fafcd9abfe6470847f8c3a81057aa9b260c6107")
-- setManifestid(1741796,"923493407518252561")
addappid(1741797,0,"b3c0705864ffb87b5be6890de5ecd919959de996b6a9a60ec6f84a3bea7bd768")
-- setManifestid(1741797,"1164136759810482559")
addappid(1741798,0,"dac1cd4282c31bca5e08c68b37b3939433252e9716025c74c0eef121dcc56938")
-- setManifestid(1741798,"5207186474495841505")
addappid(1741799,0,"962cef0a55b1ae29a391f43431ee4b98a4f54bb40cab9b0a047491df31d5b6c2")
-- setManifestid(1741799,"3355968083456807889")
addappid(1741800,0,"85cbd9ea07b0212def7701851f906cfc2015697823afa00849e0ffadacb4ee2c")
-- setManifestid(1741800,"332226608428022681")
addappid(1741801,0,"8d26e4e39b3d4f7beec6b01e44a9c7caf7d5e9eae6e499ef414cde2d79caa94b")
-- setManifestid(1741801,"842673762894090835")
addappid(1741802,0,"0452622d330096a7e928803be80e7f859a861c522eebb67fc338824122ea90cb")
-- setManifestid(1741802,"8369068266057563647")
addappid(1741803,0,"921360aefff71e9ec8ab8a2ee251e4b718ff615f3183c5fe0e0080bf7f434766")
-- setManifestid(1741803,"3889280583206658317")
addappid(1741804,0,"6d1931aa3987c3bf777944cd3240584ed15e169dc8ad97da57449f72730911cb")
-- setManifestid(1741804,"5116026304390402775")
addappid(2217480) -- Dying Light 2 Stay Human: Developer Tools
