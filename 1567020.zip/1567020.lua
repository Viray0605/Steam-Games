-- 1567020 Manifest and Lua created by Evan
-- The Dark Pictures Anthology: The Devil in Me
-- Created: November 01, 2025 at 02:43:44 
-- Total Depots: 7
-- Total DLCs: 0
-- MAIN APPLICATION



addappid(1567020) -- The Dark Pictures Anthology: The Devil in Me
addappid(228988)
-- setManifestid(228988,"6645201662696499616")
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(1567021,0,"826b5e1a80a24942cab1635c2015b33bc4a9f6d112e2e39c12fd9546540a123a")
-- setManifestid(1567021,"6828958335131979349")
addappid(1567022,0,"ef30593e1e64890edf4867a53871fbe94c12597c9dd6ead55357bc380474bd65")
-- setManifestid(1567022,"3126916074785756539")
addappid(1567023,0,"28dcdb18ee45b8bd73cc670a2f5900f7c5d61826a48e574471c6d0a7b5afa224")
-- setManifestid(1567023,"6723971401813227538")
addappid(1567024)
addappid(1567025)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2108830) -- The Dark Pictures Anthology: The Devil in Me - Curator's Cut
