-- 1326470 Manifest and Lua created by Evan
-- Sons Of The Forest
-- Created: October 29, 2025 at 10:37:05 
-- Total Depots: 1
-- Total DLCs: 0
-- MAIN APPLICATION





-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1326470) -- Sons Of The Forest
addappid(1326471,0,"dcc8b76a7563c836c1aed54a46abf85e7fec5fccabc0dd8e176d2151173e508e")
-- setManifestid(1326471, "8162016777027728069")