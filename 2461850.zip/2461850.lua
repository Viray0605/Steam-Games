-- 2461850 Manifest and Lua created by Evan
-- Senua’s Saga: Hellblade II
-- Created: November 25, 2025 at 11:47:22 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(2461850) -- Senua’s Saga: Hellblade II
-- setManifestid(228989,"3514306556860204959")
-- setManifestid(228990,"1829726630299308803")
addappid(2461851,0,"20ebd57bddf344eb01febcbdaa20afc8b1a8fe7e4bdbeecc88ca520b0df44560")
-- setManifestid(2461851,"8763532073516055148")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3199630) -- Senua’s Saga: Hellblade II Soundtrack
