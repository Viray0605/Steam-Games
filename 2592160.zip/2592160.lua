-- 2592160 Manifest and Lua created by Evan
-- Dispatch
-- Created: November 05, 2025 at 08:09:22 (UTC)
-- Total Depots: 1
-- Total DLCs: 1

-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link : https://guns.lol/f1uxin


-- MAIN APPLICATION 


































addappid(2592160) -- Dispatch

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3920280) -- Dispatch - Digital Deluxe Edition Upgrade
addappid(2592161,0,"5b4a3a4477e47584b99200004c6f4ef8cf41be05df586de9e1771e160fc7527d")
-- setManifestid(2592161,"3258962912586438634")
addappid(3920290) -- Dispatch Soundtrack
