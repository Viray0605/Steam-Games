-- 2223840 Manifest and Lua created by Evan
-- The Casting of Frank Stone™
-- Created: December 27, 2025 at 12:15:50 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION


addappid(2223840) -- The Casting of Frank Stone™
-- setManifestid(228988,"6645201662696499616")
-- setManifestid(228989,"3514306556860204959")
-- setManifestid(228990,"1829726630299308803")
-- setManifestid(229006,"1784011429307107530")
-- setManifestid(229007,"4477590687906973371")
-- setManifestid(229033,"2059065101492814639")
addappid(2223841,0,"8d0ce1b372a1cdd38319a92c98dfd920d7ea02b390a1c37efab252566f667316")
-- setManifestid(2223841,"60793258970652356")