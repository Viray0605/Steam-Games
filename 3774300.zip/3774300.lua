-- 3774300's Lua and Manifest Created by Morrenus
-- Jeff The Killer: Horror Game
-- Created: November 04, 2025 at 14:19:46 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3774300) -- Jeff The Killer: Horror Game
-- MAIN APP DEPOTS
addappid(3774302, 1, "de76b8bea219282a9e0c098ab7eb28a12427636e1138bfde76902c9098099927") -- Depot 3774302
setManifestid(3774302, "3139800460381384799", 2651976401)