-- 1888930 Manifest and Lua created by Evan
-- The Last of Us™ Part I
-- Created: November 07, 2025 at 05:50:10 (UTC)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION












-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1888930) -- The Last of Us™ Part I
addappid(1888931,0,"19cd197b4bc7e62551196ec84d00da135a4dedeb5edca50804001bf9e90b6b70")
-- setManifestid(1888931,"4945188123625783686")
addappid(1888932,0,"20a675f9d2a0efd0cf0f8985b2a1c67d5d64e1c2b5aee665d3692969b28b1be4")
-- setManifestid(1888932,"5557770133008488072")
addappid(1888933,0,"035887e659bc052ab1d1801d1665304be7da49992076cd123e25b9bd06a64134")
-- setManifestid(1888933,"7178411350218387234")